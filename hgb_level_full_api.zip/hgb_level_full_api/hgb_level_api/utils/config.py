import os
from dotenv import load_dotenv
import joblib
import xgboost as xgb
import cv2
import numpy as np
from tensorflow.keras.applications.densenet import preprocess_input
from sklearn.preprocessing import LabelEncoder, StandardScaler
from skimage.color import rgb2lab
from skimage import img_as_float
from scipy.stats import skew, kurtosis

# Load environment variables
load_dotenv(override=True)

APP_NAME = os.getenv("APP_NAME")
APP_VERSION = os.getenv("APP_VERSION")
SECRET_KEY_TOKEN = os.getenv("SECRET_KEY_TOKEN")

# Define the base directory and artifacts folder
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARTIFACTS_FOLDER_PATH = os.path.join(BASE_DIR, "artifacts")

# -------------------------
# Preprocessing Functions
# -------------------------

def segment_image(image):
    """
    Segment the conjunctiva from an image using LAB color space and contour detection.
    Returns the segmented image on a white background.
    """
    # Convert to RGB if needed
    if image.shape[2] == 3 and image.dtype == np.uint8:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Convert to LAB and extract a* channel
    lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
    a_channel = lab[:, :, 1]

    # Threshold and blur
    _, binary_mask = cv2.threshold(a_channel, 156, 255, cv2.THRESH_BINARY)
    binary_mask = cv2.GaussianBlur(binary_mask, (5, 5), 0)

    # Morphological cleaning
    kernel = np.ones((5, 5), np.uint8)
    clean_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_OPEN, kernel)
    clean_mask = cv2.morphologyEx(clean_mask, cv2.MORPH_CLOSE, kernel)

    # Focus on lower half
    height, width = clean_mask.shape
    lower_half_mask = np.zeros_like(clean_mask)
    lower_half_mask[int(height * 0.5):, :] = 255
    focused_mask = cv2.bitwise_and(clean_mask, lower_half_mask)

    # Extract largest contour
    contours, _ = cv2.findContours(focused_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        largest_contour = max(contours, key=cv2.contourArea)
        refined_mask = np.zeros_like(focused_mask)
        cv2.drawContours(refined_mask, [cv2.convexHull(largest_contour)], -1, 255, thickness=cv2.FILLED)
    else:
        refined_mask = focused_mask

    # Prepare white background with only segmented conjunctiva
    segmented_conjunctiva = cv2.bitwise_and(image, image, mask=refined_mask)
    white_background = np.full_like(image, 255)
    segmented_on_white = np.where(refined_mask[:, :, np.newaxis] == 255, segmented_conjunctiva, white_background)

    return segmented_on_white

def preprocess_image(img_path, target_size=(224, 224)):
    img = cv2.imread(img_path)
    if img is None:
        raise FileNotFoundError(f"Image not found at path: {img_path}")
    # Segment the image
    img = segment_image(img)
    img = cv2.resize(img, target_size)
    img = img.astype(np.float32)
    img = preprocess_input(img)
    return img

def read_upload_file(uploaded_file):
    contents = uploaded_file.file.read()
    np_arr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode the uploaded image.")
    return img

def preprocess_uploaded_image(image, target_size=(224, 224)):
    if image is None:
        raise ValueError("No image data provided for preprocessing.")
    # Segment the image
    image = segment_image(image)
    image = cv2.resize(image, target_size)
    image = image.astype(np.float32)
    image = preprocess_input(image)
    return image

def preprocess_metadata(df):
    # Load the saved LabelEncoder and Scaler
    label_encoder = joblib.load(os.path.join(ARTIFACTS_FOLDER_PATH, "label_encoder.pkl"))
    scaler = joblib.load(os.path.join(ARTIFACTS_FOLDER_PATH, "scaler.pkl"))

    df['gender'] = label_encoder.transform(df['Gender'])
    df = df.drop(columns=['Gender'])
    df = df.dropna()
    
    metadata = df[['Age', 'gender']]
    metadata_scaled = scaler.transform(metadata)
    
    return metadata_scaled, df


def extract_color_features(images):
    features = []
    for img in images:
        img = img_as_float(img)
        if np.isnan(img).any() or np.isinf(img).any():
            raise ValueError("Image contains NaN or infinite values.")
        
        # Mask out white background (RGB = [1, 1, 1] in float)
        mask = np.all(np.abs(img - 1.0) > 0.01, axis=2)  # Non-white pixels
        if not np.any(mask):
            raise ValueError("No non-white pixels found in segmented image.")
        
        lab = rgb2lab(img)
        L, A, B = lab[:, :, 0], lab[:, :, 1], lab[:, :, 2]
        
        # Compute statistics only on masked (non-white) regions
        L_masked = L[mask]
        A_masked = A[mask]
        B_masked = B[mask]
        
        if len(L_masked) == 0:
            raise ValueError("No valid pixels for color feature extraction.")
        
        l_mean, l_std = np.mean(L_masked), np.std(L_masked)
        l_skew, l_kurt = skew(L_masked) if len(L_masked) > 1 else 0.0, kurtosis(L_masked) if len(L_masked) > 3 else 0.0
        a_mean, a_std = np.mean(A_masked), np.std(A_masked)
        a_skew, a_kurt = skew(A_masked) if len(A_masked) > 1 else 0.0, kurtosis(A_masked) if len(A_masked) > 3 else 0.0
        b_mean, b_std = np.mean(B_masked), np.std(B_masked)
        b_skew, b_kurt = skew(B_masked) if len(B_masked) > 1 else 0.0, kurtosis(B_masked) if len(B_masked) > 3 else 0.0
        
        try:
            l_hist, _ = np.histogram(L_masked, bins=256, range=(0, 100), density=True)
            a_hist, _ = np.histogram(A_masked, bins=256, range=(-128, 128), density=True)
            b_hist, _ = np.histogram(B_masked, bins=256, range=(-128, 128), density=True)
        except RuntimeWarning as e:
            print(f"Warning during histogram calculation: {e}")
            l_hist, a_hist, b_hist = np.zeros(256), np.zeros(256), np.zeros(256)
        
        feature_vector = np.array([l_mean, l_std, l_skew, l_kurt,
                                  a_mean, a_std, a_skew, a_kurt,
                                  b_mean, b_std, b_skew, b_kurt])
        hist_features = np.concatenate([l_hist, a_hist, b_hist])
        feature_vector = np.concatenate([feature_vector, hist_features])
        
        features.append(feature_vector)
    return np.array(features)

# Group preprocessing functions into a dictionary for easy access
preprocessing = {
    "preprocess_image": preprocess_image,
    "read_upload_file": read_upload_file,
    "preprocess_uploaded_image": preprocess_uploaded_image,
    "preprocess_metadata": preprocess_metadata,
    "extract_color_features": extract_color_features,
    "segment_image": segment_image
}

# -------------------------
# Load Trained Models
# -------------------------
metadata_model = joblib.load(os.path.join(ARTIFACTS_FOLDER_PATH, "metadata_model.pkl"))
color_model = joblib.load(os.path.join(ARTIFACTS_FOLDER_PATH, "color_model.pkl"))
final_model = xgb.Booster()
final_model.load_model(os.path.join(ARTIFACTS_FOLDER_PATH, "final_model.json"))