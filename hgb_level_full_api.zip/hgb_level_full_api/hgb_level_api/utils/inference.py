import pandas as pd
import numpy as np
import xgboost as xgb
from fastapi import UploadFile
from utils.request import Request
from utils.config import preprocessing

def predict_new(data: Request, image: UploadFile, metadata_model, color_model, final_model):
    """
    Inference function for the three-model pipeline.
    """
    # -------------------------
    # Process Metadata
    # -------------------------
    df_meta = pd.DataFrame([data.dict()])
    metadata_scaled, df_processed= preprocessing["preprocess_metadata"](df_meta)
    metadata_pred = metadata_model.predict(metadata_scaled)

    # -------------------------
    # Process Uploaded Image & Extract Color Features
    # -------------------------
    uploaded_img = preprocessing["read_upload_file"](image)
    processed_img = preprocessing["preprocess_uploaded_image"](uploaded_img)
    color_features = preprocessing["extract_color_features"]([processed_img])
    color_pred = color_model.predict(color_features)

    # -------------------------
    # Final Combined Prediction
    # -------------------------
    # Combine predictions (only metadata_pred and color_pred to match trained model)
    combined_features = np.column_stack((metadata_pred, color_pred))
    # Convert to DMatrix before predicting with Booster
    dcombined = xgb.DMatrix(combined_features)
    final_pred = final_model.predict(dcombined)

    return {
        "metadata_prediction": float(metadata_pred[0]),
        "color_prediction": float(color_pred[0]),
        "final_prediction": float(final_pred[0])
    }