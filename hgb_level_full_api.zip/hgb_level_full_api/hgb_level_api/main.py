from fastapi import FastAPI, HTTPException, UploadFile, File
from utils.config import (
    APP_NAME,
    APP_VERSION,
    SECRET_KEY_TOKEN,
    metadata_model,
    color_model,
    final_model
)
from utils.request import Request
from utils.inference import predict_new

app = FastAPI(title=APP_NAME, version=APP_VERSION)


@app.get("/", tags=["health"], description="Health check of API")
async def home() -> dict:
    return {
        "app_name": APP_NAME,
        "version": APP_VERSION,
        "status": "up & running",
    }

@app.post("/predict", tags=["prediction"], description="Predict Hgb level using metadata and an uploaded image")
async def predict(data: str, image: UploadFile = File(...)) -> dict:
    try:
        # Parse the JSON string into the Request model
        from utils.request import Request  # ensure the model is imported here
        parsed_data = Request.parse_raw(data)
        response = predict_new(
            data=parsed_data,
            image=image,
            metadata_model=metadata_model,
            color_model=color_model,
            final_model=final_model
        )
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during prediction: {str(e)}")
