import os
from dotenv import load_dotenv
import joblib

load_dotenv(override=True)

APP_NAME = os.getenv("APP_NAME")
APP_VERSION = os.getenv("APP_VERSION")
SECRET_KEY_TOKEN = os.getenv("SECRET_KEY_TOKEN")

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARTIFACTS_FOLDER_PATH = os.path.join(BASE_DIR, "artifacts")

#loadmodels
preprocessor = joblib.load(os.path.join(ARTIFACTS_FOLDER_PATH, "preprocessor.pkl"))
forest_model = joblib.load(os.path.join(ARTIFACTS_FOLDER_PATH, "rf_model.pkl"))
