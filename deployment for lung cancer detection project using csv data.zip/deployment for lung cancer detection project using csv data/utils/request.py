from pydantic import BaseModel ,Field

class Request(BaseModel):
    GENDER: str = Field(description="M or F")
    AGE: int = Field(description="Age of the person")
    SMOKING: int = Field(description="1 for yes or 0 for no")
    YELLOW_FINGERS: int = Field(description="1 for yes or 0 for no")
    ANXIETY: int = Field(description="1 for yes or 0 for no")
    PEER_PRESSURE: int = Field(description="1 for yes or 0 for no")
    CHRONIC_DISEASE: int = Field(description="1 for yes or 0 for no")
    WHEEZING: int = Field(description="1 for yes or 0 for no")
    ALCOHOL_CONSUMING: int = Field(description="1 for yes or 0 for no")
    COUGHING: int = Field(description="1 for yes or 0 for no")
    SHORTNESS_OF_BREATH: int = Field(description="1 for yes or 0 for no")
    SWALLOWING_DIFFICULTY: int = Field(description="1 for yes or 0 for no")
    CHEST_PAIN: int = Field(description="1 for yes or 0 for no")
    

    