import pandas as pd
from .request import Request

def predict_new(data: Request , pipeline , model):
    
    #to df
   df= pd.DataFrame([data.model_dump()])
   
   #processing
   x_processed = pipeline.transform(df)
   
   #prediction
   y_pred = model.predict(x_processed)
   Y_prob = model.predict_proba(x_processed)
   
   return{
         "prediction": bool(y_pred[0]),
         "probability":float(Y_prob[0][1])
   }
   
   
    
    
