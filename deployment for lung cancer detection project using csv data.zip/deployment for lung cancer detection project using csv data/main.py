from fastapi import FastAPI , HTTPException
from utils.config import APP_NAME, APP_VERSION , SECRET_KEY_TOKEN , preprocessor , forest_model
from utils.request import Request
from utils.inference import predict_new
#initiaize app
app = FastAPI(title=APP_NAME, version=APP_VERSION)



@app.get("/",tags=['healthy'], description='healthy check of api')
async def home() -> dict:
    return {
        "app_name": APP_NAME,
        "version": APP_VERSION,
        "status": "up & running",
        }


@app.post("/predict_forest", tags=['prediction'], description='predict using random forest')
async def predict_forest(data: Request) -> dict:
    try:
        response= predict_new(data = data, pipeline=preprocessor, model=forest_model)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"error in using random forest, {str(e)}")
        
 